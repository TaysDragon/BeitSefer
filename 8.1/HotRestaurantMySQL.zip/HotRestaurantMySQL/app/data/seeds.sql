INSERT INTO tables (customerName, customerEmail, customerID, phoneNumber)
VALUES ("Jack Black", "jackblack@gmail.com", "jackblackID", "5127774444"),
  ("Jane Doe", "johnsmith@gmail.com", "janedoeID", "5123337777"),
  ("John Smith", "johnsmith@gmail.com",  "johnsmithID", "5129993333"),
  ("Eduardo Ponce", "eduardoponce@gmail.com",  "eduardoponceID", "5129996767");

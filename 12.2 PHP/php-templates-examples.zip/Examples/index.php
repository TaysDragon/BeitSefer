<!doctype>
<html>
  <head>
    <title>Hello, PHP</title>

    <?php require './head.php' ?>

  </head>
  <body>
    <div class="container jumbotron">
      <?php echo "<h1>Hello, PHP.</h1>" ?>
    </div>
  </body>
</html>

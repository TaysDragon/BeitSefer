<form method="get" action=""

  <fieldset class="form-group">
    <label>Name</label>
    <input type="text" class="form-control" name="name" placeholder="Your Name">
  </fieldset>

  <fieldset class="form-group">
    <label>Email</label>
    <input type="text" class="form-control" name="email" placeholder="email@domain.com">
  </fieldset>

  <fieldset class="form-group">
    <label>Age</label>
    <input type="number" class="form-control" name="age" placeholder="Age">
  </fieldset>

  <button type="submit" class="btn btn-primary">Submit</button>
</form>
